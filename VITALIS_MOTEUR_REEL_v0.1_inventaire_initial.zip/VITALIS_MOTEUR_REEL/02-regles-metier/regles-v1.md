# Règles métier V1 — Réel

Les identifiants sont provisoires et servent à la traçabilité documentaire.

## Présence et durée

| ID | Règle | Statut |
|---|---|---|
| REEL-PRE-001 | La présence est activée manuellement par l'utilisateur. | VALIDÉ |
| REEL-PRE-002 | La visibilité dans Réel est volontaire. | VALIDÉ |
| REEL-PRE-003 | Le partage de localisation est volontaire. | VALIDÉ |
| REEL-PRE-004 | Un utilisateur dispose d'un seul statut actif à la fois. | VALIDÉ |
| REEL-PRE-005 | Le rayon de proximité est personnalisable. | VALIDÉ |
| REEL-PRE-006 | Le rayon maximal est de 1 km. | VALIDÉ |
| REEL-PRE-007 | Les petits rayons 10 m, 25 m, 50 m et 100 m sont prévus. | VALIDÉ |
| REEL-PRE-008 | Les durées proposées sont 30 min, 1 h, 2 h, 3 h, 6 h, 12 h et 24 h. | VALIDÉ |
| REEL-PRE-009 | À expiration, le statut est supprimé. | VALIDÉ |
| REEL-PRE-010 | La durée est choisie par l'utilisateur, elle n'est pas fixée à une heure. | VALIDÉ |

## Intention et découverte

| ID | Règle | Statut |
|---|---|---|
| REEL-DEC-001 | Réel est un moteur de présence locale, pas un flux de publications. | VALIDÉ |
| REEL-DEC-002 | Les profils visibles sont présentés autour du profil central de l'utilisateur. | VALIDÉ |
| REEL-DEC-003 | Les profils présentés sont cliquables. | VALIDÉ |
| REEL-DEC-004 | Un indicateur numérique peut représenter un groupe de personnes au même endroit. | VALIDÉ — détail à préciser |
| REEL-DEC-005 | L'utilisateur peut consulter le profil avant de décider. | VALIDÉ |
| REEL-DEC-006 | Le statut exprime une intention dans l'instant. | VALIDÉ |

## Bips

| ID | Règle | Statut |
|---|---|---|
| REEL-BIP-001 | Les bips sont accessibles uniquement lorsque l'utilisateur est actif dans Réel. | VALIDÉ |
| REEL-BIP-002 | L'auteur peut accepter directement depuis la liste des bips. | VALIDÉ |
| REEL-BIP-003 | L'acceptation directe ne nécessite pas de renvoi de bip. | VALIDÉ |
| REEL-BIP-004 | La consultation du profil avant décision est possible. | VALIDÉ |
| REEL-BIP-005 | Un bip non accepté expire après 24 h. | VALIDÉ |
| REEL-BIP-006 | Le délai de 24 h continue même si Réel est fermé. | VALIDÉ |
| REEL-BIP-007 | Aucun historique permanent des bips n'est conservé. | VALIDÉ |
| REEL-BIP-008 | Le point de départ exact des 24 h reste à définir. | À CONFIRMER |

## Mises en relation

| ID | Règle | Statut |
|---|---|---|
| REEL-MRL-001 | Une mise en relation est créée après acceptation. | VALIDÉ |
| REEL-MRL-002 | Seules les mises en relation acceptées sont conservées dans les deux emplacements prévus. | VALIDÉ |
| REEL-MRL-003 | Les deux emplacements sont le compteur de Réel et Notifications. | VALIDÉ |
| REEL-MRL-004 | Aucun quatrième espace autonome « Temps réel » n'est ajouté. | VALIDÉ |
| REEL-MRL-005 | Une mise en relation clôturée par un participant est clôturée pour les deux. | VALIDÉ |
| REEL-MRL-006 | Une confirmation est demandée avant la clôture. | VALIDÉ |
| REEL-MRL-007 | La mise en relation disparaît immédiatement des deux espaces pour les deux participants après clôture. | VALIDÉ |
| REEL-MRL-008 | L'autre participant est informé de la clôture. | VALIDÉ |

## Communication et traces

| ID | Règle | Statut |
|---|---|---|
| REEL-COM-001 | La communication est rattachée à une mise en relation ou action autorisée. | VALIDÉ |
| REEL-COM-002 | Il n'existe pas de messagerie libre indépendante dans Réel. | VALIDÉ |
| REEL-COM-003 | La communication associée est désactivée à la clôture. | VALIDÉ |
| REEL-TRC-001 | Une trace technique minimale est conservée à la clôture. | VALIDÉ |
| REEL-TRC-002 | La trace minimale comprend date, statut et événement. | VALIDÉ |
| REEL-TRC-003 | Aucun historique de conversation n'est conservé après clôture. | VALIDÉ |
| REEL-TRC-004 | Aucun historique visible de mise en relation clôturée n'est présenté. | VALIDÉ |

## Règles à ne pas déduire

- La durée de conservation d'une mise en relation acceptée avant sa clôture n'est pas définie ici comme une durée fixe.
- La règle de 24 h porte explicitement sur les bips non acceptés ; ne pas l'appliquer automatiquement aux mises en relation acceptées.
- La trace technique minimale n'autorise pas à conserver le contenu des conversations.
- La clôture ne doit pas être traitée comme une suppression d'un seul côté : elle est réciproque.
