# Architecture technique de Réel — cadrage à concevoir

**Statut :** principes et besoins identifiés ; architecture détaillée non validée.

## 1. Objets métier à distinguer

Le modèle logique devra distinguer au minimum :
1. utilisateur/profil ;
2. présence active ;
3. zone/rayon de découverte ;
4. statut/intention ;
5. bip/demande d'intérêt ;
6. mise en relation acceptée ;
7. communication associée ;
8. notification ;
9. événement/trace technique.

Cette liste est un cadrage fonctionnel, pas un schéma SQL approuvé.

## 2. Cycle de vie à modéliser

### Présence
Inactive → activation volontaire → active → expiration ou désactivation.

### Bip
Créé → en attente → accepté ou refusé/annulé/expiré (états de refus et annulation à préciser).
Le bip non accepté expire au terme de 24 h, même si Réel a été fermé. L'origine du délai reste à préciser.

### Mise en relation
Créée après acceptation → active → clôture demandée → confirmation → clôturée pour les deux participants.
Après clôture : communication désactivée, retrait des deux espaces et trace technique minimale.

## 3. Services / responsabilités à concevoir

- gestion de présence et expiration ;
- recherche de proximité ;
- gestion des intentions ;
- gestion des bips ;
- acceptation et création de mise en relation ;
- gestion de communication ;
- notifications ;
- clôture réciproque ;
- synchronisation et reprise ;
- contrôle d'accès et audit.

La séparation en services ou modules physiques reste à déterminer selon l'architecture globale de Vitalis.

## 4. Résilience réseau

Exigences à traiter :
- conserver les actions en attente côté client lorsque le réseau est absent ;
- synchroniser au retour de la connexion ;
- éviter les doublons ;
- gérer les conflits et actions simultanées ;
- garantir qu'une clôture confirmée ne laisse pas une communication active chez l'autre participant ;
- informer les utilisateurs de l'état réel des opérations.

Le comportement hors ligne précis de chaque action reste à spécifier. Une action locale en attente ne doit pas être présentée comme acceptée par le serveur.

## 5. Cohérence distribuée

La clôture est une opération bilatérale : elle doit être traitée comme une transition unique faisant autorité côté serveur, propagée aux deux participants. Les mécanismes techniques (transaction, idempotence, événements, reprise) restent à définir.

## 6. Contrats et données

À produire ultérieurement :
- modèle de données et migrations ;
- contrats API ;
- états et transitions autorisés ;
- règles d'accès (dont RLS si Supabase est retenu pour cette partie) ;
- événements et notifications ;
- stratégie d'idempotence ;
- politique de conservation et purge ;
- tests de concurrence et de synchronisation.

Ne pas supposer que ces contrats sont déjà implémentés ou validés.
