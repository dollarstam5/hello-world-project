# Registre des décisions — Réel

Les dates sont en UTC lorsqu'elles sont issues des métadonnées de conversation. Les références de date servent à retrouver les échanges ; elles ne remplacent pas une décision signée ou un ticket de validation.

| ID | Décision | Statut | Repère |
|---|---|---|---|
| DEC-REEL-001 | Réel signifie présence locale « maintenant et tout de suite ». | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-002 | Réel n'est pas un flux de publication comme Flash. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-003 | Présence volontaire et manuelle. | VALIDÉ | Décisions antérieures |
| DEC-REEL-004 | Zone personnalisable, maximum 1 km. | VALIDÉ | Décisions antérieures |
| DEC-REEL-005 | Petits rayons : 10, 25, 50, 100 m. | VALIDÉ | Décisions antérieures |
| DEC-REEL-006 | Un seul statut actif. | VALIDÉ | Décisions antérieures |
| DEC-REEL-007 | Durées : 30 min, 1 h, 2 h, 3 h, 6 h, 12 h, 24 h. | VALIDÉ | Décisions antérieures |
| DEC-REEL-008 | À expiration, le statut est supprimé. | VALIDÉ | Décisions antérieures |
| DEC-REEL-009 | Profil utilisateur au centre, profils autour, cliquables. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-010 | Indicateurs numériques pour les regroupements. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-011 | Acceptation directe depuis la liste des bips, sans renvoi de bip. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-012 | Consultation du profil possible avant décision. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-013 | Bips accessibles uniquement lorsque l'utilisateur est actif dans Réel. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-014 | Seules les mises en relation acceptées sont conservées dans les deux emplacements. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-015 | Deux emplacements : compteur Réel et Notifications ; pas de quatrième rubrique Temps réel. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-016 | Bips non acceptés conservés 24 h, même après fermeture de Réel, puis expirés. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-017 | Clôture par un participant = clôture pour les deux. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-018 | Confirmation avant clôture. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-019 | Clôture : retrait immédiat des deux espaces pour les deux participants. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-020 | L'autre participant est informé de la clôture. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-021 | Communication désactivée après clôture. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-022 | Trace technique minimale : date, statut, événement. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-023 | Aucun historique de conversation conservé après clôture. | VALIDÉ | 9 nov. 2026 |
| DEC-REEL-024 | Pas d'historique visible de mise en relation clôturée. | VALIDÉ | 9 nov. 2026 |

## Évolution et clarification

Une discussion antérieure a envisagé une conservation de l'histoire de 12 h ou 24 h pour absorber les perturbations réseau. Les clarifications ultérieures distinguent désormais :
- les **bips non acceptés**, conservés 24 h même après fermeture de Réel ;
- les **mises en relation acceptées**, accessibles dans les deux emplacements tant qu'elles sont actives et retirées immédiatement à la clôture ;
- les **traces techniques après clôture**, limitées à date, statut et événement.

La durée de conservation d'une mise en relation acceptée non clôturée n'est pas fixée par les informations retrouvées. Le délai de 24 h ne doit pas être appliqué à cet objet sans nouvelle décision.
