# Questions ouvertes et arbitrages nécessaires

Ce document ne transforme pas les propositions en décisions. Les questions sont classées par impact.

## Priorité 1 — Cycle de vie et règles métier

1. Quel événement démarre exactement les 24 h d'un bip : création, réception côté serveur, ou autre événement ?
2. Un bip peut-il être annulé par son émetteur avant expiration ?
3. Quel est le comportement exact en cas de refus ?
4. La mise en relation acceptée reste-t-elle active sans limite jusqu'à clôture, ou existe-t-il une expiration ? Aucune durée ferme n'est confirmée.
5. Que se passe-t-il si un utilisateur désactive sa présence alors qu'une mise en relation est active ?
6. Que se passe-t-il si le statut d'origine expire alors qu'une mise en relation est active ?

## Priorité 2 — Intention et découverte

7. Quelle longueur maximale pour le titre/texte d'intention ?
8. Existe-t-il des catégories ou formats structurés ?
9. Quel est le rayon par défaut ?
10. Quels paliers sont disponibles entre 100 m et 1 km ?
11. Comment représenter plusieurs profils superposés ?
12. Quel est le seuil de regroupement et la règle exacte du compteur ?
13. La prévisualisation de trois avatars maximum, évoquée dans un récapitulatif, est-elle définitivement validée ?

## Priorité 3 — Demandes et sécurité

14. Quelles limites anti-spam s'appliquent aux bips répétitifs ?
15. Peut-on refuser, bloquer ou signaler une personne depuis Réel ?
16. Quels effets un blocage produit-il sur les présences, bips et mises en relation existantes ?
17. Quelles règles de modération s'appliquent aux intentions ?
18. Quelles informations du profil sont visibles avant acceptation et après acceptation ?

## Priorité 4 — Communication et notifications

19. Quels types de communication sont autorisés après acceptation ?
20. Le texte seul est-il confirmé pour V1 ? Le détail de la règle doit être consolidé.
21. Quels événements déclenchent une notification ?
22. Comment traiter les notifications retardées ou répétées après une coupure réseau ?
23. La clôture peut-elle être initiée lorsque l'autre participant est hors ligne ? Le principe de clôture bilatérale est validé, mais le parcours de confirmation hors ligne doit être conçu.

## Priorité 5 — Données, sécurité et technique

24. Quelle durée de conservation pour les traces techniques minimales ?
25. Quels rôles peuvent consulter ces traces ?
26. Quelle précision de localisation est nécessaire et à quelle fréquence est-elle actualisée ?
27. Quel comportement exact en cas de perte de permission de localisation ?
28. Quels contrats API, tables, index, règles d'accès et événements sont nécessaires ?
29. Quelle stratégie d'idempotence évite les doublons de bips et de mises en relation ?
30. Quelle source serveur fait autorité en cas de conflit entre deux appareils ?

## Priorité 6 — UX et validation

31. Quels sont les libellés définitifs des deux emplacements ?
32. Quels états et animations sont requis lors de l'acceptation ?
33. Quels états vides, chargement, erreur et hors ligne doivent être présentés ?
34. Quels scénarios de test constituent le seuil d'acceptation V1 ?

## Règle

Chaque réponse devra être enregistrée avec un identifiant de décision, son statut, sa date et les exigences/tests impactés. Aucune question ouverte ne doit être résolue par supposition.
