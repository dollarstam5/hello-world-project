# Inventaire fonctionnel du moteur Réel

**Statut :** inventaire initial — certaines sous-règles restent à confirmer.

## 1. Présence volontaire

- L'utilisateur peut activer manuellement sa présence dans Réel.
- Le mode de présence retenu est manuel.
- La présence est locale et temporaire.
- La localisation est partagée volontairement.
- L'utilisateur dispose d'un statut actif à la fois.
- La durée de présence est choisie parmi des durées prédéfinies.

## 2. Rayon de découverte

Valeurs évoquées et retenues :
- 10 m
- 25 m
- 50 m
- 100 m
- autres distances possibles, jusqu'à un maximum de 1 km.

Le moteur doit être particulièrement utile dans les lieux où plusieurs personnes se trouvent dans un espace restreint : salle de réunion, classe, événement ou concert.

**À confirmer :** la liste complète des paliers intermédiaires entre 100 m et 1 km, le comportement par défaut et les règles de recalcul de zone.

## 3. Statut / intention

- Un seul statut actif à la fois.
- Le statut représente une intention ou une disponibilité immédiate.
- Le statut expire à la fin de la durée choisie.
- À expiration, le statut est supprimé.

**À confirmer :** longueur maximale, formats autorisés, catégories, édition du statut actif et modération.

## 4. Découverte des personnes

- Le profil de l'utilisateur est placé au centre de la représentation visuelle.
- Les profils des personnes visibles apparaissent autour de lui.
- Les profils sont cliquables.
- Plusieurs personnes présentes dans un même lieu doivent pouvoir être visualisées.
- Des indicateurs numériques peuvent signaler un regroupement de personnes (ex. 5 ou 6 personnes au même endroit).
- La représentation utilise une zone circulaire/radiale, avec des rayons visuels fixes et des profils distribués autour du centre.

**À confirmer :** règle de positionnement des profils, gestion du chevauchement, seuil de regroupement, précision géographique et comportement d'accessibilité.

## 5. Bips et demandes

- Les bips sont accessibles lorsque l'utilisateur est actif dans Réel.
- L'auteur peut accepter directement depuis la liste des bips.
- Il n'est pas nécessaire de renvoyer un bip pour accepter.
- La consultation du profil est également possible avant la décision.
- Les bips non acceptés ont une conservation temporaire de 24 h, y compris après fermeture de Réel, puis expirent.
- Il n'existe pas d'historique permanent des bips.

**À confirmer :** origine exacte du délai de 24 h (création, réception ou autre événement), états du bip, refus, annulation, anti-répétition et limites de fréquence.

## 6. Mises en relation acceptées

- Seules les mises en relation acceptées sont conservées dans les deux emplacements prévus.
- Les deux accès convenus sont le compteur de Réel et l'espace Notifications.
- Aucun quatrième élément distinct « Temps réel » ne doit être ajouté.
- Les deux emplacements donnent accès aux mises en relation concernées selon les conditions d'activité de l'utilisateur.
- Une mise en relation clôturée disparaît immédiatement des deux espaces pour les deux participants.

**À confirmer :** libellés exacts, règles d'affichage du compteur, ordre de tri et comportement quand l'utilisateur n'est plus actif dans Réel.

## 7. Communication

- La communication est liée à une mise en relation ou à une action autorisée.
- Réel ne permet pas une messagerie libre indépendante.
- Les modalités de contact après acceptation doivent respecter le choix prévu par le parcours.
- À la clôture, la communication associée est désactivée.

**À confirmer :** types de messages, pièces jointes éventuelles, indicateurs de lecture, appels, blocage, signalement et durée de vie de la conversation.

## 8. Notifications

- L'autre participant est informé lorsqu'une mise en relation est clôturée.
- L'espace Notifications est l'un des deux accès retenus pour les mises en relation acceptées.

**À confirmer :** catalogue complet des événements, priorités, regroupement, préférences, livraison différée et comportement hors ligne.
