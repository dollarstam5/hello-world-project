# Périmètres V1, V2 et V3 — Réel

## V1 — Socle fonctionnel

Les éléments suivants sont retenus comme base V1 dans les décisions retrouvées :

- présence manuelle, volontaire et locale ;
- rayon personnalisable, maximum 1 km, avec petits paliers 10 m, 25 m, 50 m et 100 m ;
- un seul statut actif ;
- durées prédéfinies : 30 min, 1 h, 2 h, 3 h, 6 h, 12 h, 24 h ;
- suppression du statut à expiration ;
- découverte visuelle avec profil central et profils autour ;
- profils cliquables et regroupements numériques ;
- bips accessibles lorsque l'utilisateur est actif ;
- consultation du profil et acceptation directe depuis la liste des bips ;
- expiration des bips non acceptés après 24 h, même si Réel est fermé ;
- conservation des mises en relation acceptées dans deux emplacements : compteur Réel et Notifications ;
- clôture réciproque après confirmation ;
- désactivation de la communication après clôture ;
- disparition immédiate de la mise en relation des deux espaces pour les deux participants ;
- notification de l'autre participant ;
- trace technique minimale : date, statut, événement ;
- aucun historique de conversation après clôture ;
- prise en compte des perturbations réseau et de la synchronisation.

La liste constitue le périmètre fonctionnel retrouvé, pas un certificat d'implémentation.

## V2 — À définir

Aucune liste détaillée de fonctionnalités V2 n'est suffisamment confirmée dans les éléments retrouvés. Les demandes, blocages, signalements, anti-abus et raffinements de communication doivent être arbitrés avant affectation à une version.

## V3 — À définir

Aucune liste détaillée V3 n'est suffisamment confirmée. Ne pas y classer automatiquement les idées non décidées.

## Règle de gouvernance

Une fonctionnalité ne passe en V1 que si :
1. elle est explicitement décidée ;
2. ses règles métier sont définies ;
3. ses états et cas limites sont documentés ;
4. ses critères d'acceptation sont testables ;
5. sa faisabilité et ses coûts sont compatibles avec les contraintes Vitalis V1.

Les fonctionnalités futures restent hors V1 tant qu'elles ne sont pas arbitrées.
