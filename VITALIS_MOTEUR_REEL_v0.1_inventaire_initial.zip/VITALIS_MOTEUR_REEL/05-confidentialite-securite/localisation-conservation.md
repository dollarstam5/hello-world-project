# Confidentialité, localisation et conservation

## 1. Présence et localisation

Décisions :
- visibilité volontaire ;
- présence manuelle ;
- partage de localisation volontaire ;
- zone de proximité personnalisable ;
- rayon maximal de 1 km.

À concevoir :
- permissions système ;
- refus de permission ;
- précision de localisation réellement nécessaire ;
- fréquence de mise à jour ;
- protection contre la triangulation et la localisation abusive ;
- comportement lorsque la localisation devient indisponible ;
- suppression des données de localisation après usage.

## 2. Temporalité

Durées de présence validées :
- 30 minutes ;
- 1 heure ;
- 2 heures ;
- 3 heures ;
- 6 heures ;
- 12 heures ;
- 24 heures.

À expiration, le statut est supprimé.

## 3. Bips non acceptés

Règle validée le 9 novembre 2026 :
- conservation temporaire pendant 24 heures ;
- le délai continue même après fermeture de Réel ;
- le bip non accepté expire ;
- aucun historique permanent.

Le point de départ exact du délai reste à définir.

## 4. Mises en relation acceptées

- Les mises en relation acceptées sont accessibles dans deux emplacements.
- À la clôture, elles disparaissent immédiatement des deux emplacements pour les deux participants.
- Aucun historique visible de clôture n'est conservé.
- La communication est désactivée.

Ne pas confondre la durée de vie d'un bip non accepté (24 h) avec celle d'une mise en relation acceptée. La durée maximale d'une mise en relation acceptée tant qu'elle n'est pas clôturée reste à arbitrer.

## 5. Trace technique minimale après clôture

Informations explicitement retenues :
- date ;
- dernier statut ;
- événement.

Finalités : cohérence et traçabilité technique minimale.

Exclusions :
- aucun historique de conversation ;
- aucune mise en relation active après clôture ;
- aucun historique visible pour les utilisateurs.

À préciser : durée de conservation technique, accès autorisés, pseudonymisation, journalisation, obligations légales et procédure de suppression.

## 6. Sécurité et confiance

Chantiers à spécifier :
- authentification et autorisation ;
- contrôle d'accès aux profils et mises en relation ;
- règles serveur faisant autorité ;
- protection contre les accès croisés ;
- prévention des abus et demandes répétées ;
- blocage et signalement ;
- limitation de débit ;
- validation et nettoyage des intentions ;
- audit des événements sensibles.

Aucune implémentation de sécurité n'est prouvée par ce document.
