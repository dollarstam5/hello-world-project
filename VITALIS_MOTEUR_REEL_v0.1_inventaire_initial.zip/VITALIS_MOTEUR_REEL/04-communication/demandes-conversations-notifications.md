# Demandes, conversations et notifications

## 1. Principe

La communication de Réel n'est pas une messagerie libre. Elle est associée à une mise en relation ou à une action autorisée.

## 2. Séquence fonctionnelle de référence

1. Un utilisateur publie une présence avec une intention.
2. Une autre personne manifeste son intérêt (bip).
3. L'auteur peut consulter le profil de cette personne.
4. L'auteur peut accepter directement depuis la liste des bips.
5. Une mise en relation acceptée est créée.
6. Les accès à cette mise en relation sont disponibles dans les deux emplacements retenus : compteur Réel et Notifications.
7. La communication associée peut être activée selon les règles du parcours.
8. Un participant peut demander la clôture.
9. Une confirmation est requise.
10. La clôture s'applique aux deux participants, la communication est désactivée, l'autre personne est informée et la mise en relation disparaît des deux emplacements.

## 3. Acceptation

Décisions :
- Acceptation directe depuis la liste des bips.
- Pas de renvoi de bip pour accepter.
- Consultation du profil possible avant décision.

**À confirmer :** l'acceptation est-elle toujours immédiate ou existe-t-il une étape de confirmation ? Quels états sont visibles pour l'émetteur du bip ?

## 4. Refus, annulation et blocage

Ces sujets ont été identifiés comme restant à compléter :
- refus explicite d'un bip ;
- annulation par l'émetteur ;
- blocage d'un utilisateur ;
- signalement ;
- gestion des bips répétitifs ;
- prévention des abus et du harcèlement.

Aucune règle détaillée n'est considérée comme validée dans ce dossier.

## 5. Conversation

Règles fermes :
- pas de messagerie libre autonome ;
- communication rattachée à une mise en relation/action autorisée ;
- communication désactivée à la clôture ;
- aucun historique de conversation conservé après clôture.

À spécifier : formats, longueur, pièces jointes, modération, notifications de nouveaux messages, accès en cas de perte réseau et comportement d'un participant bloqué.

## 6. Notifications

Événement explicitement retenu :
- notification de l'autre participant lors de la clôture.

L'espace Notifications est également l'un des deux accès aux mises en relation acceptées.

Le catalogue complet des notifications reste à établir : nouveau bip, acceptation, expiration, changement de disponibilité, synchronisation retardée, etc. Ne pas considérer ces événements comme validés avant arbitrage.
