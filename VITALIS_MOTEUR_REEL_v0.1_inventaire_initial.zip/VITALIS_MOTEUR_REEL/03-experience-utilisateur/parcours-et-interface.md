# Parcours et expérience utilisateur de Réel

**Direction UX validée :** moderne, intelligente, simple, vivante, premium sans surcharge cognitive.

## 1. Entrée dans Réel

Réel est un moteur indépendant dans la navigation Vitalis. Il ne faut pas confondre l'écran Home de Vitalis avec la page du moteur Réel.

## 2. Activation de présence

Parcours de travail :
1. L'utilisateur ouvre Réel.
2. Il choisit d'activer sa présence.
3. Il autorise le partage de localisation selon les permissions du système.
4. Il choisit un rayon de proximité.
5. Il rédige ou sélectionne son intention/statut.
6. Il choisit la durée de présence.
7. Il devient visible dans sa zone.

Les étapes exactes, les valeurs par défaut et les états de permission refusée sont à confirmer.

## 3. Écran principal

Principes retenus :
- profil de l'utilisateur au centre ;
- zone circulaire/radiale autour de lui ;
- profils à proximité distribués autour du centre ;
- profils sélectionnables ;
- indicateurs numériques pour les regroupements ;
- informations présentées avec hiérarchie visuelle et bonne lisibilité.

La visualisation ne doit pas créer de fausse précision de positionnement. Les règles de géolocalisation et d'affichage devront être définies par l'architecture et la confidentialité.

## 4. Cartes et regroupements

L'utilisateur souhaite une présentation moderne des cartes côte à côte lorsque cela est pertinent, avec une bonne mise en page et une lecture rapide.

Un groupe de personnes au même endroit peut être représenté par un indicateur numérique (ex. 5 ou 6). La prévisualisation de trois avatars maximum a été évoquée dans un récapitulatif de décisions ; son statut exact doit être confirmé avant de la traiter comme règle ferme.

## 5. Bips et acceptation

- L'utilisateur actif peut consulter ses bips.
- Il peut consulter le profil de l'émetteur.
- Il peut accepter directement depuis la liste.
- L'interface ne doit pas imposer un renvoi de bip.
- L'acceptation peut être accompagnée d'une confirmation ou animation, sous réserve de validation des détails UX.

## 6. Accès aux mises en relation

Deux emplacements sont retenus :
1. compteur dans Réel ;
2. Notifications.

Aucun quatrième onglet ou espace autonome « Temps réel » ne doit être ajouté.

## 7. Clôture

- L'utilisateur déclenche la clôture.
- Une confirmation est demandée.
- Après confirmation, la clôture s'applique aux deux participants.
- La communication est désactivée.
- La mise en relation disparaît immédiatement des deux espaces.
- L'autre participant est informé.

## 8. Qualité UX

- Mobile-first.
- Interface responsive.
- Faible charge mentale.
- États vides, chargement, erreur, hors ligne et reprise clairement conçus.
- Animations utiles, jamais indispensables à la compréhension.
- Accessibilité et lisibilité à traiter dans les spécifications d'écran.

**À confirmer :** wireframes, libellés exacts, comportement des gestes, états détaillés, animation d'acceptation et règles d'accessibilité.
