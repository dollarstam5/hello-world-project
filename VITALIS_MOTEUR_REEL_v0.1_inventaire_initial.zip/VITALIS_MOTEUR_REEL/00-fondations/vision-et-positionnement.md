# Vision et positionnement de Réel

**Statut :** VALIDÉ pour la vision générale  
**Périmètre :** V1 comme socle du moteur, détails à décliner.

## 1. Définition

Réel est le moteur de présence locale et de mise en relation immédiate de Vitalis. Son idée centrale est : **« la maintenant et tout de suite »**.

Il permet à une personne d'être volontairement visible dans son environnement actuel, d'exprimer une intention courte et de découvrir d'autres personnes présentes à proximité. Une interaction peut ensuite conduire à une mise en relation, selon les règles d'acceptation définies.

## 2. Ce que Réel est

- Un espace vivant de présence dans l'environnement immédiat.
- Un moyen de découvrir des personnes dans une même zone physique : salle, classe, réunion, événement, stade ou espace public.
- Un espace où un utilisateur peut afficher un titre ou une description représentant son intention du moment.
- Un moteur de découverte et de mise en relation contextualisée.
- Une expérience temporaire, volontaire et locale.

## 3. Ce que Réel n'est pas

Réel ne doit pas être confondu avec Flash.

- **Réel :** présence et visibilité locale en temps réel, avec intention contextualisée.
- **Flash :** publication de contenu. Réel ne doit pas devenir un fil de publications.

Réel n'est pas non plus une messagerie libre autonome. La communication éventuelle est rattachée à une mise en relation ou à une action autorisée.

## 4. Exemples d'intentions

Exemples illustratifs évoqués dans les échanges :

- « Je veux discuter avec une voisine. »
- « J'offre un plat de nourriture à qui arrive le premier. »
- « Je propose un travail de 30 minutes. »

Ces exemples montrent que le contenu de présence doit exprimer une intention compréhensible et contextualisée. Les limites de longueur, catégories, modération et champs obligatoires restent à spécifier.

## 5. Principes directeurs

1. **Volontariat :** la présence et le partage de localisation sont activés par l'utilisateur.
2. **Proximité :** la découverte concerne l'environnement autour de l'utilisateur.
3. **Temporalité :** la présence et les intentions ne sont pas un historique social permanent.
4. **Clarté :** une présence, une intention, un bip et une mise en relation sont des objets distincts.
5. **Contrôle :** l'auteur garde le contrôle de l'acceptation des demandes et de la suite de la mise en relation.
6. **Simplicité :** interface moderne, intelligente, lisible et à faible charge mentale.
7. **Résilience :** les perturbations réseau et retards de synchronisation doivent être pris en compte.
8. **Traçabilité minimale :** conserver uniquement les traces techniques nécessaires selon les règles retenues.

## 6. Résultat attendu

Un utilisateur actif doit pouvoir comprendre rapidement :
- qu'il est présent ou non ;
- quelles personnes sont visibles autour de lui ;
- quelles intentions sont proposées ;
- quelles demandes le concernent ;
- quelles mises en relation sont actives ;
- comment mettre fin à une mise en relation.

## 7. Distinction avec la preuve de réalisation

La vision et les règles décrites ici sont des décisions produit. Elles ne prouvent pas que les routes, composants, services, données ou tests correspondants existent dans l'application.
