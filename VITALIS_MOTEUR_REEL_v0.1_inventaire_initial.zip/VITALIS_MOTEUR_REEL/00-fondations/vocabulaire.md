# Vocabulaire fonctionnel de Réel

| Terme | Définition de travail | Distinction |
|---|---|---|
| Présence | État volontaire indiquant qu'un utilisateur est visible dans Réel | N'est pas une publication |
| Zone / rayon | Périmètre de proximité utilisé pour la découverte | Ne signifie pas partage public permanent de la position |
| Statut / intention | Texte ou titre court exprimant ce que l'utilisateur souhaite dans l'instant | N'est pas une conversation |
| Profil | Informations consultables sur une personne | Consultation possible avant décision |
| Bip | Demande ou manifestation d'intérêt adressée à l'auteur d'une intention | Ne doit pas être confondu avec une mise en relation acceptée |
| Acceptation | Décision de l'auteur d'accepter une demande | Peut être faite directement depuis la liste des bips |
| Mise en relation | Relation fonctionnelle créée après acceptation | Elle est distincte de la présence et du bip |
| Communication / conversation | Canal associé à une mise en relation autorisée | Pas de messagerie libre indépendante |
| Clôture | Fin de la mise en relation | Clôture réciproque pour les deux participants |
| Trace technique | Métadonnées minimales conservées pour cohérence et audit | Pas un historique visible ni un historique de conversation |

**À confirmer :** le terme « bip » doit recevoir une définition UX et technique stable (objet, acteur émetteur, destinataire, états et événements). Le présent dossier reprend le mot utilisé dans les échanges.
