# VITALIS — Dossier autonome du moteur Réel

**Version documentaire :** 0.1 — inventaire initial  
**Date :** 9 novembre 2026  
**Statut global :** document de travail — à réconcilier et valider  
**Périmètre :** moteur Réel de Vitalis, indépendant du dépôt GitHub principal.

## Objet

Ce dossier rassemble les décisions connues issues des échanges consacrés à Réel. Il constitue une base de référence lisible par un produit, un développeur ou une IA. Il ne constitue pas une preuve de réalisation technique.

## Principes de lecture

- **VALIDÉ** : décision explicitement acceptée par l'utilisateur ou contrainte clairement formulée.
- **À CONFIRMER** : information évoquée, mais formulation finale, portée ou arbitrage incomplet.
- **PROPOSITION** : organisation ou recommandation documentaire, pas une règle métier approuvée.
- **NON DÉMONTRÉ** : aucune preuve de fonctionnement effectif n'est disponible dans ce dossier.
- **V1 / V2 / V3** : périmètres temporels. Une idée future ne doit pas être présentée comme une fonctionnalité V1.

Les dates des décisions sont indiquées lorsqu'elles sont connues. En cas de divergence entre une formulation ancienne et une clarification ultérieure, la clarification la plus récente prévaut, tout en conservant la trace de l'évolution.

## Structure

| Dossier | Contenu |
|---|---|
| `00-fondations/` | Vision, identité, objectifs, vocabulaire |
| `01-fonctionnalites/` | Présence, découverte, profils, bips, mises en relation |
| `02-regles-metier/` | Règles numérotées et cycles de vie |
| `03-experience-utilisateur/` | Parcours, interface, cartes et états |
| `04-communication/` | Acceptation, conversation, notifications, clôture |
| `05-confidentialite-securite/` | Localisation, visibilité, conservation, protection |
| `06-architecture-technique/` | Modèle logique, synchronisation, responsabilités |
| `07-tests-validation/` | Scénarios et preuves attendues |
| `08-evolution/` | Périmètres V1/V2/V3 et limites |
| `09-decisions/` | Registre des décisions et questions ouvertes |

## État de cette première livraison

Cette livraison est un **recensement initial** à partir des informations disponibles dans les conversations et du contexte de décisions retrouvé. Elle ne prétend pas être l'extraction exhaustive de chaque message historique. Les éléments incomplets sont signalés plutôt que complétés par supposition.

## Documents à lire en premier

1. `00-fondations/vision-et-positionnement.md`
2. `01-fonctionnalites/inventaire-fonctionnel.md`
3. `02-regles-metier/regles-v1.md`
4. `09-decisions/registre-des-decisions.md`
5. `09-decisions/questions-ouvertes.md`

## Limites importantes

- Ce dossier n'affirme pas que Réel est déjà implémenté.
- Les scénarios de test décrits sont des attentes, pas des résultats de tests exécutés.
- Les règles techniques détaillées (schéma SQL, API, RLS, protocoles de synchronisation) restent à concevoir ou à vérifier.
- Aucun fichier n'est destiné à être injecté automatiquement dans le dépôt GitHub Vitalis.
