# Tests et validation du moteur Réel

**Statut :** catalogue initial de scénarios attendus ; aucun résultat d'exécution n'est affirmé.

## 1. Présence

- Activer volontairement la présence.
- Refuser la permission de localisation.
- Choisir chacun des rayons retenus.
- Vérifier le plafond de 1 km.
- Choisir chacune des durées prédéfinies.
- Vérifier la suppression du statut à expiration.
- Vérifier qu'un seul statut est actif.

## 2. Découverte

- Afficher le profil central et les profils à proximité.
- Cliquer sur un profil.
- Afficher plusieurs profils dans un même lieu.
- Afficher un regroupement avec compteur.
- Vérifier l'accessibilité et la lisibilité lorsque les profils se chevauchent.

## 3. Bips

- Envoyer un bip.
- Consulter la liste des bips lorsque Réel est actif.
- Vérifier que l'accès est limité à l'état actif convenu.
- Ouvrir le profil de l'émetteur.
- Accepter directement depuis la liste sans renvoi de bip.
- Vérifier l'expiration au terme de 24 h après détermination de l'événement de départ.
- Fermer Réel puis vérifier que le délai continue.
- Vérifier l'absence d'historique permanent après expiration.

## 4. Mises en relation

- Créer une mise en relation après acceptation.
- Vérifier les deux emplacements : compteur Réel et Notifications.
- Vérifier qu'aucun espace autonome « Temps réel » supplémentaire n'est créé.
- Vérifier l'accès des deux participants.
- Clôturer depuis le premier participant.
- Vérifier la confirmation.
- Vérifier la clôture pour les deux participants.
- Vérifier la disparition immédiate dans les deux emplacements.
- Vérifier la notification de l'autre participant.

## 5. Communication et conservation

- Vérifier que la communication est liée à la mise en relation.
- Vérifier qu'elle est désactivée après clôture.
- Vérifier qu'aucun historique de conversation n'est conservé après clôture.
- Vérifier la trace technique minimale (date, statut, événement).
- Vérifier qu'aucun historique visible de mise en relation clôturée n'est exposé.

## 6. Résilience réseau

- Perdre le réseau pendant une action.
- Restaurer le réseau.
- Vérifier la reprise et la synchronisation.
- Rejouer une action et vérifier l'absence de doublon.
- Simuler deux actions concurrentes.
- Simuler une clôture pendant que l'autre participant est hors ligne.
- Vérifier la cohérence finale côté serveur et sur les deux appareils.

## 7. Preuves requises

Pour chaque scénario :
- identifiant du test ;
- préconditions ;
- étapes ;
- résultat attendu ;
- résultat observé ;
- environnement et version ;
- preuve (journal, capture, rapport automatisé) ;
- statut : non exécuté, réussi, échoué ou bloqué.

**Important :** une règle écrite ou un scénario attendu n'est pas une preuve d'exécution.
